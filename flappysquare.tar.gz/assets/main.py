import asyncio  # 1. Aggiunto per il supporto Web
import pygame
import sys
import random
import math

# 2. Inizializzazione Mixer specifica per il Web (toglie l'audio cursed)
pygame.mixer.pre_init(44100, -16, 2, 1024)
pygame.init()

async def main():
    # === RISOLUZIONE BASE DEL GIOCO ===
    WIDTH, HEIGHT = 800, 600

    # Usiamo una dimensione fissa all'avvio per Pygbag, poi gestiamo il resize
    screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
    pygame.display.set_caption("Flappy Square!")
    clock = pygame.time.Clock()
    FPS = 60

    game_surface = pygame.Surface((WIDTH, HEIGHT))

    # === CARICAMENTO RISORSE ===
    # Uso percorsi relativi per essere sicuro che Pygbag li veda
    bg_img       = pygame.transform.scale(pygame.image.load("background.png"), (WIDTH, HEIGHT))
    bird_img     = pygame.transform.scale(pygame.image.load("bird.png"), (50, 40))
    pipe_img     = pygame.image.load("pipe.png")
    gameover_img = pygame.transform.scale(pygame.image.load("game_over.png"), (500, 150))

    TUBE_WIDTH = 120
    TUBE_GAP   = 200
    pipe_top_img = pygame.transform.scale(pipe_img, (TUBE_WIDTH, HEIGHT))
    pipe_bottom_img = pygame.transform.flip(pipe_top_img, False, True)

    # === AUDIO ===
    jump_snd  = pygame.mixer.Sound("jump.ogg")
    hit_snd   = pygame.mixer.Sound("hit.ogg")
    point_snd = pygame.mixer.Sound("point.ogg")

    pygame.mixer.music.load("background_music.ogg")
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1)

    # === COSTANTI E VARIABILI ===
    GRAVITY        = 0.5
    JUMP_STRENGTH  = -10
    INITIAL_SPEED  = 5
    PIPE_FREQ_MS   = 1500
    font_small = pygame.font.Font(None, 36)
    font_big   = pygame.font.Font(None, 90)

    state       = "title"
    bird_x      = 100
    bird_y      = HEIGHT // 2
    bird_vy     = 0
    rotation    = 0
    pipes       = []
    last_pipe   = pygame.time.get_ticks()
    score       = 0
    best_score  = 0
    pipe_speed  = INITIAL_SPEED
    bird_rect = pygame.Rect(bird_x, bird_y, 50, 40)
    menu_time = 0
    menu_pipes = [{"x": 500, "h": 250}, {"x": 800, "h": 200}]

    # Helper functions spostate dentro o rese accessibili
    def disegna_testo(surf, txt, x, y, font, col=(255,255,255)):
        surf.blit(font.render(txt, True, col), (x, y))

    def reset_game_local():
        nonlocal bird_y, bird_vy, pipes, last_pipe, score, pipe_speed, rotation
        bird_y     = HEIGHT // 2
        bird_vy    = 0
        rotation   = 0
        pipes      = []
        last_pipe  = pygame.time.get_ticks()
        score      = 0
        pipe_speed = INITIAL_SPEED

    running = True

    # === LOOP PRINCIPALE ASINCRONO ===
    while running:
        dt = clock.tick(FPS)
        menu_time += dt / 1000

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            if e.type == pygame.VIDEORESIZE:
                screen = pygame.display.set_mode((e.w, e.h), pygame.RESIZABLE)

            if (e.type == pygame.KEYDOWN and e.key == pygame.K_SPACE) or e.type == pygame.MOUSEBUTTONDOWN:
                if state == "title":
                    state = "waiting"
                elif state == "waiting":
                    bird_vy = JUMP_STRENGTH
                    jump_snd.play()
                    state = "playing"
                elif state == "playing":
                    bird_vy = JUMP_STRENGTH
                    jump_snd.play()
                elif state == "gameover":
                    reset_game_local()
                    state = "waiting"

        # --- LOGICA GIOCO ---
        if state == "playing":
            bird_vy += GRAVITY
            bird_y  += bird_vy
            rotation = max(min(-bird_vy * 3, 30), -30)

            now = pygame.time.get_ticks()
            if now - last_pipe > PIPE_FREQ_MS:
                last_pipe = now
                h = random.randint(100, HEIGHT - TUBE_GAP - 100)
                pipes.append({"x": WIDTH, "h": h, "scored": False})

            for p in pipes:
                p["x"] -= pipe_speed
                if not p["scored"] and bird_x > p["x"] + TUBE_WIDTH:
                    score += 1
                    point_snd.play()
                    p["scored"] = True
                    if score % 5 == 0: pipe_speed += 1

            pipes = [p for p in pipes if p["x"] + TUBE_WIDTH > 0]
            bird_rect.topleft = (bird_x, bird_y)

            for p in pipes:
                top_rect = pygame.Rect(p["x"], 0, TUBE_WIDTH, p["h"])
                bot_rect = pygame.Rect(p["x"], p["h"] + TUBE_GAP, TUBE_WIDTH, HEIGHT - p["h"] - TUBE_GAP)
                if bird_rect.colliderect(top_rect) or bird_rect.colliderect(bot_rect) or bird_y < 0 or bird_y > HEIGHT:
                    hit_snd.play()
                    best_score = max(best_score, score)
                    state = "gameover"
                    break

        # --- DISEGNO ---
        game_surface.blit(bg_img, (0, 0))
        if state == "title":
            for p in menu_pipes:
                p["x"] -= 2
                if p["x"] < -TUBE_WIDTH: p["x"] = WIDTH + 200
                game_surface.blit(pipe_bottom_img, (p["x"], p["h"] - HEIGHT))
                game_surface.blit(pipe_top_img, (p["x"], p["h"] + TUBE_GAP))
            idle_y = HEIGHT//2 + math.sin(menu_time * 2) * 15
            game_surface.blit(bird_img, (bird_x, idle_y))
            disegna_testo(game_surface, "FLAPPY SQUARE", WIDTH//2 - 200, HEIGHT//4, font_big, (0,0,0))
            if int(menu_time * 2) % 2 == 0:
                disegna_testo(game_surface, "Press SPACE or Click", WIDTH//2 - 140, HEIGHT - 100, font_small, (0,0,0))
        else:
            for p in pipes:
                game_surface.blit(pipe_bottom_img, (p["x"], p["h"] - HEIGHT))
                game_surface.blit(pipe_top_img, (p["x"], p["h"] + TUBE_GAP))
            b = pygame.transform.rotate(bird_img, rotation) if state == "playing" else bird_img
            game_surface.blit(b, (bird_x, bird_y))
            disegna_testo(game_surface, f"Score: {score}", 10, 10, font_small, (0,0,0))
            if state == "waiting":
                disegna_testo(game_surface, "Click o SPACE per volare!", WIDTH//2 - 120, HEIGHT//2, font_small)
            elif state == "gameover":
                game_surface.blit(gameover_img, (WIDTH//2 - 250, HEIGHT//4))
                disegna_testo(game_surface, f"Final: {score}  Best: {best_score}", WIDTH//2 - 120, HEIGHT//2 + 50, font_small, (0,0,0))
                disegna_testo(game_surface, "Clicca per riprovare!", WIDTH//2 - 152, HEIGHT//2+75, font_small, (0,0,0))

        # Scaling e refresh
        scaled_surface = pygame.transform.smoothscale(game_surface, screen.get_size())
        screen.blit(scaled_surface, (0,0))
        pygame.display.flip()

        # 3. FONDAMENTALE: Cede il controllo al browser
        await asyncio.sleep(0)

    pygame.quit()

# 4. Avvio dell'app asincrona
asyncio.run(main())
